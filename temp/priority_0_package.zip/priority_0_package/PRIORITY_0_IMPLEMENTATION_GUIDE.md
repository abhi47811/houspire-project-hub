# Priority 0: Smart Defaults Implementation Guide

**Date:** December 28, 2025  
**Author:** Manus AI  
**Purpose:** Complete guide to implement Priority 0 (Critical) features

---

## 🎯 What This Implements

This guide covers **Priority 0: Critical** items that block the core workflow:

1. ✅ Fix `smart_defaults` schema and load 168 combinations
2. ✅ Connect smart defaults to UI (replace mock data)
3. ✅ Add `budget_tier` to projects table
4. ✅ Save `smart_default_id` to rooms table

**Estimated Time:** 1-2 hours  
**Difficulty:** Medium

---

## 📦 Files You Need

| File | Purpose |
|------|---------|
| `migration_fix_smart_defaults.sql` | Database schema fix + functions |
| `load_smart_defaults_improved.js` | Node.js data loader |
| `load_smart_defaults_sql.py` | Python SQL generator (alternative) |
| `verify_smart_defaults.sql` | Verification script |
| `smart_defaults_complete.json` | 168 combinations data (2.5 MB) |

---

## 🚀 Step-by-Step Implementation

### **STEP 1: Run the Migration (5 minutes)**

This fixes the schema, creates helper functions, and adds budget_tier column.

**Instructions:**

1. Open Supabase Dashboard → SQL Editor
2. Click "New Query"
3. Copy entire contents of `migration_fix_smart_defaults.sql`
4. Paste and click "Run"
5. Wait for completion (~5 seconds)

**Expected Output:**
```
DROP TABLE
CREATE TABLE
CREATE INDEX (3x)
ALTER TABLE (2x)
CREATE POLICY (2x)
NOTICE: Added budget_tier column to projects table
CREATE FUNCTION (4x)
CREATE TRIGGER
```

**Verify:**
```sql
SELECT COUNT(*) FROM information_schema.tables 
WHERE table_name = 'smart_defaults';
```
Expected: 1

---

### **STEP 2: Load the Data (10-15 minutes)**

**Option A: Node.js Script (Recommended)**

1. Install dependencies:
   ```bash
   npm install @supabase/supabase-js
   ```

2. Set environment variables:
   ```bash
   export SUPABASE_URL="https://your-project.supabase.co"
   export SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"
   ```

3. Run the loader:
   ```bash
   node load_smart_defaults_improved.js smart_defaults_complete.json
   ```

4. If table already has data:
   ```bash
   node load_smart_defaults_improved.js smart_defaults_complete.json --clear
   ```

**Expected Output:**
```
✅ Supabase client initialized
📖 Step 1: Reading JSON file...
✅ Found 168 combinations
🔍 Step 2: Checking existing data...
✅ Table is empty, proceeding
🔄 Step 3: Transforming data...
✅ Transformed 168 records
✔️  Step 4: Validating data...
✅ All records valid
📥 Step 5: Inserting data...
📦 Batch 1/4: Inserting records 1-50...
✅ Batch 1 inserted (50 records)
...
✅ Successfully inserted 168 records
🎉 DATA LOADING COMPLETE!
```

**Option B: Generate SQL File**

If you can't use Node.js:

1. Generate SQL:
   ```bash
   python3 load_smart_defaults_sql.py smart_defaults_complete.json output.sql
   ```

2. Open `output.sql` in text editor
3. Copy contents
4. Paste into Supabase SQL Editor
5. Run

**Verify:**
```sql
SELECT COUNT(*) FROM smart_defaults;
```
Expected: 168

---

### **STEP 3: Verify Installation (5 minutes)**

Run the verification script:

1. Open Supabase SQL Editor
2. Copy contents of `verify_smart_defaults.sql`
3. Paste and run
4. Review output

**Look for these checks:**
- ✅ Table exists
- ✅ 168 records loaded
- ✅ 13 styles available
- ✅ 13 room types available
- ✅ Foreign key exists
- ✅ budget_tier column exists
- ✅ Helper functions work

If any show ❌, review the previous steps.

---

### **STEP 4: Update Frontend (30-45 minutes)**

Now connect the UI to the real database.

#### **4.1: Update PhaseCustomize Component**

**File:** `src/components/rooms/PhaseCustomize.tsx`

**Find this code (around line 147):**
```typescript
const { data: smartDefaults } = useQuery({
  queryKey: ['smart-defaults', room.room_type, selectedStyle],
  queryFn: async () => {
    if (!selectedStyle) return null;
    return mockSmartDefaults[selectedStyle] || mockSmartDefaults.contemporary;
  },
  enabled: !!selectedStyle,
});
```

**Replace with:**
```typescript
const { data: smartDefaults } = useQuery({
  queryKey: ['smart-defaults', room.room_type, selectedStyle],
  queryFn: async () => {
    if (!selectedStyle || !room.room_type) return null;
    
    const { data, error } = await supabase
      .rpc('get_smart_default', {
        p_style: selectedStyle,
        p_room_type: room.room_type
      });
    
    if (error) {
      console.error('Error fetching smart defaults:', error);
      return null;
    }
    
    return data?.[0] || null;
  },
  enabled: !!selectedStyle && !!room.room_type,
});
```

#### **4.2: Save smart_default_id When User Applies**

**Find this code (around line 266):**
```typescript
const handleApplyAndContinue = async () => {
  if (!selectedStyle) {
    toast({
      title: 'Select a Style',
      description: 'Please select a design style before continuing.',
      variant: 'destructive',
    });
    return;
  }

  setIsApplying(true);
  try {
    const { error } = await supabase
      .from('rooms')
      .update({
        selected_style: selectedStyle,
        phase_4_completed: true,
        current_phase: Math.max(room.current_phase, 5),
      })
      .eq('id', room.id);
```

**Replace with:**
```typescript
const handleApplyAndContinue = async () => {
  if (!selectedStyle) {
    toast({
      title: 'Select a Style',
      description: 'Please select a design style before continuing.',
      variant: 'destructive',
    });
    return;
  }

  setIsApplying(true);
  try {
    // Fetch the smart default ID
    const { data: smartDefaultData } = await supabase
      .rpc('get_smart_default', {
        p_style: selectedStyle,
        p_room_type: room.room_type
      });
    
    const smartDefaultId = smartDefaultData?.[0]?.id || null;
    
    // Update room with style AND smart_default_id
    const { error } = await supabase
      .from('rooms')
      .update({
        selected_style: selectedStyle,
        smart_default_id: smartDefaultId, // NEW
        phase_4_completed: true,
        current_phase: Math.max(room.current_phase, 5),
      })
      .eq('id', room.id);
```

#### **4.3: Remove Mock Data Import**

**Find and remove:**
```typescript
import { mockSmartDefaults } from '@/data/mockSmartDefaults';
```

You can now delete the mock data file if it exists.

---

### **STEP 5: Test the Integration (10 minutes)**

Test that everything works end-to-end:

1. **Create a new project**
   - Verify budget tier dropdown appears
   - Select a budget tier
   - Create project

2. **Upload a room image**
   - Complete Phase 1-3 (upload, mask, clean)

3. **Enter Phase 4: Customize**
   - Click on a design style
   - Wait for smart defaults to load
   - Verify you see:
     - Specifications
     - Checklist items
     - Finishes
   - Click "Apply & Continue"

4. **Verify in database:**
   ```sql
   SELECT 
     id,
     room_type,
     selected_style,
     smart_default_id
   FROM rooms
   WHERE id = 'YOUR_ROOM_ID';
   ```
   - `selected_style` should be populated
   - `smart_default_id` should be a valid UUID

---

## 🧪 Testing Checklist

- [ ] Migration ran successfully
- [ ] 168 records loaded into smart_defaults table
- [ ] Verification script shows all ✅
- [ ] Frontend loads real data (not mock)
- [ ] Style selector shows 13 styles
- [ ] Clicking a style loads specifications, checklist, finishes
- [ ] Applying saves smart_default_id to rooms table
- [ ] Budget tier can be selected during project creation
- [ ] No console errors

---

## 🔧 Troubleshooting

### **Problem: Migration fails**

**Error:** "table already exists"

**Solution:**
```sql
DROP TABLE IF EXISTS public.smart_defaults CASCADE;
```
Then re-run migration.

---

### **Problem: Data loading fails**

**Error:** "permission denied"

**Solution:** You need the service role key (not anon key). Get it from:
- Supabase Dashboard → Settings → API → service_role key

---

### **Problem: Frontend shows no data**

**Check 1:** Verify data is in database:
```sql
SELECT COUNT(*) FROM smart_defaults;
```

**Check 2:** Check browser console for errors

**Check 3:** Verify RPC function works:
```sql
SELECT * FROM get_smart_default('Modern Indian', 'Living Room');
```

---

### **Problem: smart_default_id not saving**

**Check:** Verify column exists:
```sql
SELECT column_name FROM information_schema.columns 
WHERE table_name = 'rooms' AND column_name = 'smart_default_id';
```

If missing, add it:
```sql
ALTER TABLE rooms ADD COLUMN smart_default_id UUID REFERENCES smart_defaults(id);
```

---

## 📊 Success Metrics

After implementation, you should see:

| Metric | Target | How to Verify |
|--------|--------|---------------|
| Records in database | 168 | `SELECT COUNT(*) FROM smart_defaults;` |
| Styles available | 13 | `SELECT COUNT(DISTINCT style) FROM smart_defaults;` |
| Room types available | 13 | `SELECT COUNT(DISTINCT room_type) FROM smart_defaults;` |
| Frontend loads real data | Yes | Check network tab, no mock data |
| smart_default_id saves | Yes | Check rooms table after applying |
| Budget tier saves | Yes | Check projects table after creation |

---

## 🎯 What's Next

After completing Priority 0, move to **Priority 1**:

1. Connect library references to AI generation
2. Build comprehensive prompt that combines smart defaults + library + custom requirements
3. Add refinement UI in Phase 5

But first, **test thoroughly** to ensure Priority 0 is solid!

---

## 📝 Quick Reference

### **Database Queries**

```sql
-- Get smart default
SELECT * FROM get_smart_default('Modern Indian', 'Living Room');

-- List all styles
SELECT * FROM get_available_styles();

-- List all room types
SELECT * FROM get_available_room_types();

-- Check a room's smart default
SELECT 
  r.id,
  r.room_type,
  r.selected_style,
  sd.style,
  sd.room_type
FROM rooms r
LEFT JOIN smart_defaults sd ON r.smart_default_id = sd.id
WHERE r.id = 'YOUR_ROOM_ID';
```

### **Environment Variables**

```bash
export SUPABASE_URL="https://your-project.supabase.co"
export SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"
```

### **File Locations**

- Migration: `migration_fix_smart_defaults.sql`
- Data loader: `load_smart_defaults_improved.js`
- Data file: `smart_defaults_complete.json`
- Verification: `verify_smart_defaults.sql`
- Frontend: `src/components/rooms/PhaseCustomize.tsx`

---

**Implementation Complete!** 🎉

You now have:
- ✅ 168 smart defaults loaded
- ✅ Frontend connected to real data
- ✅ Budget tier selection
- ✅ smart_default_id tracking

This is the foundation for the complete Houspire workflow!
