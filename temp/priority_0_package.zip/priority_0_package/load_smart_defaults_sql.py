#!/usr/bin/env python3
"""
============================================================================
SMART DEFAULTS DATA LOADER (Python + SQL)
============================================================================
Purpose: Generate SQL INSERT statements from JSON file
Author: Manus AI
Date: 2025-12-28

This script reads smart_defaults_complete.json and generates a SQL file
with INSERT statements that can be executed directly in Supabase SQL Editor.

Usage:
  python3 load_smart_defaults_sql.py smart_defaults_complete.json output.sql

============================================================================
"""

import json
import sys
import re
from pathlib import Path

def to_slug(text):
    """Convert text to slug format"""
    return re.sub(r'[^a-z0-9]+', '_', text.lower()).strip('_')

def escape_sql_string(text):
    """Escape single quotes for SQL"""
    if text is None:
        return 'NULL'
    return text.replace("'", "''")

def json_to_sql(json_obj):
    """Convert JSON object to SQL-safe string"""
    return escape_sql_string(json.dumps(json_obj, ensure_ascii=False))

def generate_insert_statement(record):
    """Generate a single INSERT statement"""
    style = escape_sql_string(record['style'])
    room_type = escape_sql_string(record['room_type'])
    style_slug = to_slug(record['style'])
    room_type_slug = to_slug(record['room_type'])
    source_file = escape_sql_string(record.get('source_file', ''))
    
    specifications = json_to_sql(record.get('specifications', []))
    checklist = json_to_sql(record.get('checklist', []))
    finishes = json_to_sql(record.get('finishes', []))
    
    return f"""INSERT INTO public.smart_defaults (style, room_type, style_slug, room_type_slug, specifications, checklist, finishes, source_file)
VALUES ('{style}', '{room_type}', '{style_slug}', '{room_type_slug}', '{specifications}'::jsonb, '{checklist}'::jsonb, '{finishes}'::jsonb, '{source_file}')
ON CONFLICT (style_slug, room_type_slug) DO UPDATE SET
  specifications = EXCLUDED.specifications,
  checklist = EXCLUDED.checklist,
  finishes = EXCLUDED.finishes,
  source_file = EXCLUDED.source_file,
  updated_at = NOW();
"""

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 load_smart_defaults_sql.py <input.json> <output.sql>")
        sys.exit(1)
    
    input_file = Path(sys.argv[1])
    output_file = Path(sys.argv[2])
    
    if not input_file.exists():
        print(f"Error: Input file not found: {input_file}")
        sys.exit(1)
    
    print(f"Reading JSON from: {input_file}")
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    if 'combinations' not in data or not isinstance(data['combinations'], list):
        print("Error: Invalid JSON structure. Expected 'combinations' array.")
        sys.exit(1)
    
    combinations = data['combinations']
    print(f"Found {len(combinations)} combinations")
    
    print(f"Generating SQL statements...")
    
    sql_statements = []
    sql_statements.append("-- ============================================================================")
    sql_statements.append("-- SMART DEFAULTS DATA LOAD")
    sql_statements.append("-- ============================================================================")
    sql_statements.append(f"-- Generated from: {input_file.name}")
    sql_statements.append(f"-- Total records: {len(combinations)}")
    sql_statements.append(f"-- Generated on: 2025-12-28")
    sql_statements.append("-- ============================================================================\n")
    
    sql_statements.append("-- Start transaction")
    sql_statements.append("BEGIN;\n")
    
    for i, record in enumerate(combinations, 1):
        sql_statements.append(f"-- Record {i}/{len(combinations)}: {record['style']} - {record['room_type']}")
        sql_statements.append(generate_insert_statement(record))
    
    sql_statements.append("-- Commit transaction")
    sql_statements.append("COMMIT;\n")
    
    sql_statements.append("-- ============================================================================")
    sql_statements.append("-- VERIFICATION QUERIES")
    sql_statements.append("-- ============================================================================\n")
    
    sql_statements.append("-- Check total count")
    sql_statements.append("SELECT COUNT(*) as total_records FROM public.smart_defaults;\n")
    
    sql_statements.append("-- Check styles")
    sql_statements.append("SELECT style, COUNT(*) as room_count FROM public.smart_defaults GROUP BY style ORDER BY style;\n")
    
    sql_statements.append("-- Check room types")
    sql_statements.append("SELECT room_type, COUNT(*) as style_count FROM public.smart_defaults GROUP BY room_type ORDER BY room_type;\n")
    
    sql_statements.append("-- Test get_smart_default function")
    sql_statements.append("SELECT * FROM public.get_smart_default('Modern Indian', 'Living Room');\n")
    
    sql_statements.append("-- Test get_available_styles function")
    sql_statements.append("SELECT * FROM public.get_available_styles();\n")
    
    sql_statements.append("-- Test get_available_room_types function")
    sql_statements.append("SELECT * FROM public.get_available_room_types();\n")
    
    sql_content = '\n'.join(sql_statements)
    
    print(f"Writing SQL to: {output_file}")
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(sql_content)
    
    print(f"\n✅ SQL file generated successfully!")
    print(f"   File size: {output_file.stat().st_size / 1024 / 1024:.2f} MB")
    print(f"   Total statements: {len(combinations)}")
    print(f"\n📝 Next steps:")
    print(f"   1. Open Supabase SQL Editor")
    print(f"   2. Copy and paste the contents of {output_file}")
    print(f"   3. Execute the SQL")
    print(f"   4. Verify using the verification queries at the end")
    print()

if __name__ == '__main__':
    main()
