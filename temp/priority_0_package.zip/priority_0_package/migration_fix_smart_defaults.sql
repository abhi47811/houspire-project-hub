-- ============================================================================
-- MIGRATION: Fix Smart Defaults Schema and Add Budget Tier
-- ============================================================================
-- Purpose: Drop the incorrect smart_defaults table and recreate with correct
--          schema. Also add budget_tier column to projects table.
-- Author: Manus AI
-- Date: 2025-12-28
-- ============================================================================

-- STEP 1: Drop the old incorrect smart_defaults table
-- This will cascade and remove the foreign key constraint from rooms table
DROP TABLE IF EXISTS public.smart_defaults CASCADE;

-- STEP 2: Create the new correct smart_defaults table
CREATE TABLE public.smart_defaults (
  -- Primary Key
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Style and Room Type Information
  style TEXT NOT NULL,
  room_type TEXT NOT NULL,
  style_slug TEXT NOT NULL,
  room_type_slug TEXT NOT NULL,
  
  -- Design Data (JSONB for flexibility)
  specifications JSONB NOT NULL DEFAULT '[]'::jsonb,
  checklist JSONB NOT NULL DEFAULT '[]'::jsonb,
  finishes JSONB NOT NULL DEFAULT '[]'::jsonb,
  
  -- Metadata
  source_file TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  -- Ensure unique combination of style and room type
  CONSTRAINT unique_style_room UNIQUE (style_slug, room_type_slug)
);

-- Add table comment
COMMENT ON TABLE public.smart_defaults IS 'Pre-configured design specifications for each style+room combination (168 total combinations)';

-- Add column comments
COMMENT ON COLUMN public.smart_defaults.style IS 'Human-readable style name (e.g., "Modern Indian")';
COMMENT ON COLUMN public.smart_defaults.room_type IS 'Human-readable room type (e.g., "Living Room")';
COMMENT ON COLUMN public.smart_defaults.style_slug IS 'URL-safe style slug (e.g., "modern_indian")';
COMMENT ON COLUMN public.smart_defaults.room_type_slug IS 'URL-safe room type slug (e.g., "living_room")';
COMMENT ON COLUMN public.smart_defaults.specifications IS 'Array of specification objects with categories and items';
COMMENT ON COLUMN public.smart_defaults.checklist IS 'Array of checklist items to include in the design';
COMMENT ON COLUMN public.smart_defaults.finishes IS 'Array of finish specifications (flooring, ceiling, walls, etc.)';
COMMENT ON COLUMN public.smart_defaults.source_file IS 'Original Excel filename for reference';

-- STEP 3: Create indexes for performance
CREATE INDEX idx_smart_defaults_style_slug ON public.smart_defaults(style_slug);
CREATE INDEX idx_smart_defaults_room_type_slug ON public.smart_defaults(room_type_slug);
CREATE INDEX idx_smart_defaults_lookup ON public.smart_defaults(style_slug, room_type_slug);

-- STEP 4: Enable Row Level Security
ALTER TABLE public.smart_defaults ENABLE ROW LEVEL SECURITY;

-- STEP 5: Create RLS Policies
-- Allow all authenticated users to read smart defaults
CREATE POLICY "Allow authenticated users to read smart defaults" 
  ON public.smart_defaults 
  FOR SELECT 
  TO authenticated
  USING (true);

-- Allow admins to manage smart defaults
CREATE POLICY "Allow admins to manage smart defaults" 
  ON public.smart_defaults 
  FOR ALL 
  USING (public.get_user_role(auth.uid()) = 'admin');

-- STEP 6: Re-add the foreign key constraint to rooms table
-- The constraint was dropped when we dropped the smart_defaults table
ALTER TABLE public.rooms 
  ADD CONSTRAINT rooms_smart_default_id_fkey
  FOREIGN KEY (smart_default_id) 
  REFERENCES public.smart_defaults(id) 
  ON DELETE SET NULL;

-- STEP 7: Add budget_tier column to projects table if it doesn't exist
DO $$ 
BEGIN
  -- Check if column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_schema = 'public'
      AND table_name = 'projects' 
      AND column_name = 'budget_tier'
  ) THEN
    -- Add the column
    ALTER TABLE public.projects 
      ADD COLUMN budget_tier TEXT DEFAULT 'mid_range';
    
    -- Add constraint to ensure valid values
    ALTER TABLE public.projects 
      ADD CONSTRAINT budget_tier_check 
      CHECK (budget_tier IN ('premium', 'mid_range', 'budget'));
    
    -- Add comment
    COMMENT ON COLUMN public.projects.budget_tier IS 
      'Budget tier for the project: premium (2.5x multiplier), mid_range (1.0x), or budget (0.5x)';
    
    RAISE NOTICE 'Added budget_tier column to projects table';
  ELSE
    RAISE NOTICE 'budget_tier column already exists in projects table';
  END IF;
END $$;

-- STEP 8: Create helper functions for querying smart defaults

-- Function: Get smart default by style and room type
CREATE OR REPLACE FUNCTION public.get_smart_default(
  p_style TEXT, 
  p_room_type TEXT
)
RETURNS TABLE (
  id UUID, 
  style TEXT, 
  room_type TEXT, 
  specifications JSONB, 
  checklist JSONB, 
  finishes JSONB
)
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    sd.id, 
    sd.style, 
    sd.room_type, 
    sd.specifications, 
    sd.checklist, 
    sd.finishes
  FROM public.smart_defaults sd
  WHERE sd.style_slug = lower(replace(p_style, ' ', '_'))
    AND sd.room_type_slug = lower(replace(p_room_type, ' ', '_'))
  LIMIT 1;
END;
$$;

COMMENT ON FUNCTION public.get_smart_default IS 'Fetch smart default by style and room type names (case-insensitive)';

-- Function: Get all available styles
CREATE OR REPLACE FUNCTION public.get_available_styles()
RETURNS TABLE (
  style TEXT, 
  style_slug TEXT,
  room_count INTEGER
)
LANGUAGE sql 
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    style, 
    style_slug,
    COUNT(*)::INTEGER as room_count
  FROM public.smart_defaults 
  GROUP BY style, style_slug
  ORDER BY style;
$$;

COMMENT ON FUNCTION public.get_available_styles IS 'Get list of all available design styles with room counts';

-- Function: Get all available room types
CREATE OR REPLACE FUNCTION public.get_available_room_types()
RETURNS TABLE (
  room_type TEXT, 
  room_type_slug TEXT,
  style_count INTEGER
)
LANGUAGE sql 
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    room_type, 
    room_type_slug,
    COUNT(*)::INTEGER as style_count
  FROM public.smart_defaults 
  GROUP BY room_type, room_type_slug
  ORDER BY room_type;
$$;

COMMENT ON FUNCTION public.get_available_room_types IS 'Get list of all available room types with style counts';

-- Function: Get smart defaults for a specific room
-- This function takes a room_id and returns the appropriate smart default
-- based on the room's type and selected style
CREATE OR REPLACE FUNCTION public.get_smart_default_for_room(p_room_id UUID)
RETURNS TABLE (
  id UUID, 
  style TEXT, 
  room_type TEXT, 
  specifications JSONB, 
  checklist JSONB, 
  finishes JSONB
)
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_room_type TEXT;
  v_selected_style TEXT;
BEGIN
  -- Fetch room details
  SELECT r.room_type, r.selected_style
  INTO v_room_type, v_selected_style
  FROM public.rooms r
  WHERE r.id = p_room_id;
  
  -- If room not found or missing data, return empty
  IF v_room_type IS NULL OR v_selected_style IS NULL THEN
    RETURN;
  END IF;
  
  -- Return the smart default
  RETURN QUERY
  SELECT * FROM public.get_smart_default(v_selected_style, v_room_type);
END;
$$;

COMMENT ON FUNCTION public.get_smart_default_for_room IS 'Get smart default for a specific room based on its type and selected style';

-- STEP 9: Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_smart_defaults_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_smart_defaults_updated_at
  BEFORE UPDATE ON public.smart_defaults
  FOR EACH ROW
  EXECUTE FUNCTION public.update_smart_defaults_updated_at();

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================
-- Run these after the migration to verify everything is correct

-- Verify table structure
-- SELECT column_name, data_type, is_nullable
-- FROM information_schema.columns
-- WHERE table_name = 'smart_defaults'
-- ORDER BY ordinal_position;

-- Verify indexes
-- SELECT indexname, indexdef
-- FROM pg_indexes
-- WHERE tablename = 'smart_defaults';

-- Verify RLS policies
-- SELECT policyname, permissive, roles, cmd, qual
-- FROM pg_policies
-- WHERE tablename = 'smart_defaults';

-- Verify foreign key constraint
-- SELECT conname, contype, confupdtype, confdeltype
-- FROM pg_constraint
-- WHERE conrelid = 'public.rooms'::regclass
--   AND conname = 'rooms_smart_default_id_fkey';

-- Verify budget_tier column
-- SELECT column_name, data_type, column_default
-- FROM information_schema.columns
-- WHERE table_name = 'projects' AND column_name = 'budget_tier';

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
-- Next step: Load data using the data loading script
-- ============================================================================
