-- ============================================================================
-- SMART DEFAULTS VERIFICATION SCRIPT
-- ============================================================================
-- Purpose: Verify that smart_defaults table is correctly set up and populated
-- Author: Manus AI
-- Date: 2025-12-28
-- ============================================================================

-- ============================================================================
-- SECTION 1: TABLE STRUCTURE VERIFICATION
-- ============================================================================

\echo '============================================================================'
\echo 'SECTION 1: TABLE STRUCTURE VERIFICATION'
\echo '============================================================================'

-- Check if table exists
\echo '\n1.1 Checking if smart_defaults table exists...'
SELECT 
  CASE 
    WHEN EXISTS (
      SELECT 1 FROM information_schema.tables 
      WHERE table_schema = 'public' AND table_name = 'smart_defaults'
    ) 
    THEN '✅ Table exists'
    ELSE '❌ Table does NOT exist'
  END as status;

-- Check table structure
\echo '\n1.2 Checking table columns...'
SELECT 
  column_name, 
  data_type, 
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'smart_defaults'
ORDER BY ordinal_position;

-- Check constraints
\echo '\n1.3 Checking table constraints...'
SELECT 
  conname as constraint_name,
  contype as constraint_type,
  pg_get_constraintdef(oid) as definition
FROM pg_constraint
WHERE conrelid = 'public.smart_defaults'::regclass;

-- Check indexes
\echo '\n1.4 Checking indexes...'
SELECT 
  indexname, 
  indexdef
FROM pg_indexes
WHERE schemaname = 'public' AND tablename = 'smart_defaults';

-- ============================================================================
-- SECTION 2: DATA VERIFICATION
-- ============================================================================

\echo '\n============================================================================'
\echo 'SECTION 2: DATA VERIFICATION'
\echo '============================================================================'

-- Total record count
\echo '\n2.1 Total record count...'
SELECT 
  COUNT(*) as total_records,
  CASE 
    WHEN COUNT(*) = 168 THEN '✅ Expected 168 records'
    WHEN COUNT(*) = 0 THEN '❌ No data loaded'
    ELSE '⚠️  Unexpected count (expected 168)'
  END as status
FROM public.smart_defaults;

-- Count by style
\echo '\n2.2 Records per style...'
SELECT 
  style,
  COUNT(*) as room_count,
  CASE 
    WHEN COUNT(*) = 13 THEN '✅'
    WHEN COUNT(*) = 12 THEN '⚠️  Missing 1 room'
    ELSE '❌'
  END as status
FROM public.smart_defaults
GROUP BY style
ORDER BY style;

-- Count by room type
\echo '\n2.3 Records per room type...'
SELECT 
  room_type,
  COUNT(*) as style_count,
  CASE 
    WHEN COUNT(*) = 13 THEN '✅'
    WHEN COUNT(*) = 12 THEN '⚠️  Missing 1 style'
    ELSE '❌'
  END as status
FROM public.smart_defaults
GROUP BY room_type
ORDER BY room_type;

-- Check for duplicates
\echo '\n2.4 Checking for duplicates...'
SELECT 
  style_slug,
  room_type_slug,
  COUNT(*) as duplicate_count
FROM public.smart_defaults
GROUP BY style_slug, room_type_slug
HAVING COUNT(*) > 1;

\echo 'If no rows returned above, ✅ No duplicates found'

-- Check for NULL values
\echo '\n2.5 Checking for NULL values in critical columns...'
SELECT 
  COUNT(*) FILTER (WHERE style IS NULL) as null_style,
  COUNT(*) FILTER (WHERE room_type IS NULL) as null_room_type,
  COUNT(*) FILTER (WHERE style_slug IS NULL) as null_style_slug,
  COUNT(*) FILTER (WHERE room_type_slug IS NULL) as null_room_type_slug,
  COUNT(*) FILTER (WHERE specifications IS NULL) as null_specifications,
  COUNT(*) FILTER (WHERE checklist IS NULL) as null_checklist,
  COUNT(*) FILTER (WHERE finishes IS NULL) as null_finishes
FROM public.smart_defaults;

\echo 'All values should be 0'

-- Check JSONB structure
\echo '\n2.6 Checking JSONB data structure...'
SELECT 
  style,
  room_type,
  jsonb_array_length(specifications) as spec_count,
  jsonb_array_length(checklist) as checklist_count,
  jsonb_array_length(finishes) as finish_count
FROM public.smart_defaults
LIMIT 5;

-- ============================================================================
-- SECTION 3: FUNCTION VERIFICATION
-- ============================================================================

\echo '\n============================================================================'
\echo 'SECTION 3: FUNCTION VERIFICATION'
\echo '============================================================================'

-- Check if functions exist
\echo '\n3.1 Checking if helper functions exist...'
SELECT 
  routine_name,
  routine_type,
  CASE 
    WHEN routine_name IN ('get_smart_default', 'get_available_styles', 'get_available_room_types', 'get_smart_default_for_room')
    THEN '✅'
    ELSE '⚠️'
  END as status
FROM information_schema.routines
WHERE routine_schema = 'public' 
  AND routine_name LIKE '%smart_default%'
ORDER BY routine_name;

-- Test get_smart_default function
\echo '\n3.2 Testing get_smart_default function...'
SELECT 
  id,
  style,
  room_type,
  jsonb_array_length(specifications) as spec_count,
  jsonb_array_length(checklist) as checklist_count,
  jsonb_array_length(finishes) as finish_count
FROM public.get_smart_default('Modern Indian', 'Living Room');

\echo 'Expected: 1 row with Modern Indian Living Room data'

-- Test get_available_styles function
\echo '\n3.3 Testing get_available_styles function...'
SELECT * FROM public.get_available_styles();

\echo 'Expected: 13 rows (one per style)'

-- Test get_available_room_types function
\echo '\n3.4 Testing get_available_room_types function...'
SELECT * FROM public.get_available_room_types();

\echo 'Expected: 13 rows (one per room type)'

-- ============================================================================
-- SECTION 4: FOREIGN KEY VERIFICATION
-- ============================================================================

\echo '\n============================================================================'
\echo 'SECTION 4: FOREIGN KEY VERIFICATION'
\echo '============================================================================'

-- Check if foreign key exists on rooms table
\echo '\n4.1 Checking foreign key constraint on rooms table...'
SELECT 
  conname as constraint_name,
  pg_get_constraintdef(oid) as definition
FROM pg_constraint
WHERE conrelid = 'public.rooms'::regclass
  AND conname = 'rooms_smart_default_id_fkey';

\echo 'Expected: 1 row showing FK to smart_defaults(id)'

-- Check rooms table has smart_default_id column
\echo '\n4.2 Checking if rooms table has smart_default_id column...'
SELECT 
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns
WHERE table_schema = 'public' 
  AND table_name = 'rooms' 
  AND column_name = 'smart_default_id';

\echo 'Expected: 1 row showing UUID column'

-- ============================================================================
-- SECTION 5: PROJECTS TABLE VERIFICATION
-- ============================================================================

\echo '\n============================================================================'
\echo 'SECTION 5: PROJECTS TABLE VERIFICATION'
\echo '============================================================================'

-- Check if budget_tier column exists
\echo '\n5.1 Checking if projects table has budget_tier column...'
SELECT 
  column_name,
  data_type,
  column_default,
  is_nullable
FROM information_schema.columns
WHERE table_schema = 'public' 
  AND table_name = 'projects' 
  AND column_name = 'budget_tier';

\echo 'Expected: 1 row showing TEXT column with default value'

-- Check budget_tier constraint
\echo '\n5.2 Checking budget_tier constraint...'
SELECT 
  conname as constraint_name,
  pg_get_constraintdef(oid) as definition
FROM pg_constraint
WHERE conrelid = 'public.projects'::regclass
  AND conname = 'budget_tier_check';

\echo 'Expected: 1 row showing CHECK constraint for valid values'

-- ============================================================================
-- SECTION 6: RLS POLICIES VERIFICATION
-- ============================================================================

\echo '\n============================================================================'
\echo 'SECTION 6: RLS POLICIES VERIFICATION'
\echo '============================================================================'

-- Check if RLS is enabled
\echo '\n6.1 Checking if RLS is enabled on smart_defaults...'
SELECT 
  tablename,
  rowsecurity as rls_enabled
FROM pg_tables
WHERE schemaname = 'public' AND tablename = 'smart_defaults';

\echo 'Expected: rls_enabled = true'

-- Check RLS policies
\echo '\n6.2 Checking RLS policies...'
SELECT 
  policyname,
  permissive,
  roles,
  cmd,
  qual
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'smart_defaults';

\echo 'Expected: 2 policies (one for authenticated users, one for admins)'

-- ============================================================================
-- SECTION 7: SAMPLE DATA VERIFICATION
-- ============================================================================

\echo '\n============================================================================'
\echo 'SECTION 7: SAMPLE DATA VERIFICATION'
\echo '============================================================================'

-- Show sample specifications
\echo '\n7.1 Sample specifications (Modern Indian Living Room)...'
SELECT 
  style,
  room_type,
  jsonb_pretty(specifications) as specifications
FROM public.smart_defaults
WHERE style_slug = 'modern_indian' AND room_type_slug = 'living_room';

-- Show sample checklist
\echo '\n7.2 Sample checklist (Contemporary Kitchen)...'
SELECT 
  style,
  room_type,
  jsonb_pretty(checklist) as checklist
FROM public.smart_defaults
WHERE style_slug = 'contemporary' AND room_type_slug = 'kitchen';

-- Show sample finishes
\echo '\n7.3 Sample finishes (Minimalist Master Bedroom)...'
SELECT 
  style,
  room_type,
  jsonb_pretty(finishes) as finishes
FROM public.smart_defaults
WHERE style_slug = 'minimalist' AND room_type_slug = 'master_bedroom';

-- ============================================================================
-- SECTION 8: FINAL SUMMARY
-- ============================================================================

\echo '\n============================================================================'
\echo 'SECTION 8: FINAL SUMMARY'
\echo '============================================================================'

SELECT 
  '✅ Table exists' as check_1,
  CASE WHEN (SELECT COUNT(*) FROM public.smart_defaults) = 168 
    THEN '✅ 168 records loaded' 
    ELSE '❌ Incorrect record count' 
  END as check_2,
  CASE WHEN (SELECT COUNT(*) FROM public.get_available_styles()) = 13 
    THEN '✅ 13 styles available' 
    ELSE '❌ Incorrect style count' 
  END as check_3,
  CASE WHEN (SELECT COUNT(*) FROM public.get_available_room_types()) = 13 
    THEN '✅ 13 room types available' 
    ELSE '❌ Incorrect room type count' 
  END as check_4,
  CASE WHEN EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conrelid = 'public.rooms'::regclass 
      AND conname = 'rooms_smart_default_id_fkey'
  ) 
    THEN '✅ Foreign key exists' 
    ELSE '❌ Foreign key missing' 
  END as check_5,
  CASE WHEN EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'projects' AND column_name = 'budget_tier'
  ) 
    THEN '✅ budget_tier column exists' 
    ELSE '❌ budget_tier column missing' 
  END as check_6;

\echo '\n============================================================================'
\echo 'VERIFICATION COMPLETE'
\echo '============================================================================'
\echo 'Review the output above. All checks should show ✅'
\echo 'If any checks show ❌, review the migration and data loading steps.'
\echo '============================================================================'
