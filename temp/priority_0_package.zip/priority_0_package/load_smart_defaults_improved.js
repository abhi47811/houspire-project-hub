/**
 * ============================================================================
 * SMART DEFAULTS DATA LOADER (Node.js)
 * ============================================================================
 * Purpose: Load 168 smart defaults combinations from JSON file into Supabase
 * Author: Manus AI
 * Date: 2025-12-28
 * 
 * Prerequisites:
 * 1. Run migration_fix_smart_defaults.sql first
 * 2. Install dependencies: npm install @supabase/supabase-js
 * 3. Set environment variables: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY
 * 
 * Usage:
 *   node load_smart_defaults_improved.js path/to/smart_defaults_complete.json [--skip|--clear|--append]
 * ============================================================================
 */

const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');

// ============================================================================
// CONFIGURATION
// ============================================================================

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const BATCH_SIZE = 50; // Insert in batches to avoid timeouts

// ============================================================================
// VALIDATION
// ============================================================================

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('❌ Error: Missing environment variables');
  console.error('   Please set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY');
  process.exit(1);
}

const jsonFilePath = process.argv[2];
if (!jsonFilePath) {
  console.error('❌ Error: Missing JSON file path');
  console.error('   Usage: node load_smart_defaults_improved.js path/to/smart_defaults_complete.json [--skip|--clear|--append]');
  process.exit(1);
}

if (!fs.existsSync(jsonFilePath)) {
  console.error(`❌ Error: File not found: ${jsonFilePath}`);
  process.exit(1);
}

// ============================================================================
// INITIALIZE SUPABASE CLIENT
// ============================================================================

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

console.log('✅ Supabase client initialized');

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Convert a string to slug format (lowercase with underscores)
 */
function toSlug(str) {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

/**
 * Transform JSON data to match database schema
 */
function transformRecord(record) {
  return {
    style: record.style,
    room_type: record.room_type,
    style_slug: toSlug(record.style),
    room_type_slug: toSlug(record.room_type),
    specifications: record.specifications || [],
    checklist: record.checklist || [],
    finishes: record.finishes || [],
    source_file: record.source_file || null
  };
}

/**
 * Insert records in batches
 */
async function insertBatch(records, batchNumber, totalBatches) {
  const startIdx = (batchNumber - 1) * BATCH_SIZE;
  const endIdx = Math.min(startIdx + BATCH_SIZE, records.length);
  const batch = records.slice(startIdx, endIdx);
  
  console.log(`\n📦 Batch ${batchNumber}/${totalBatches}: Inserting records ${startIdx + 1}-${endIdx}...`);
  
  const { data, error } = await supabase
    .from('smart_defaults')
    .insert(batch)
    .select('id, style, room_type');
  
  if (error) {
    console.error(`❌ Error inserting batch ${batchNumber}:`, error.message);
    throw error;
  }
  
  console.log(`✅ Batch ${batchNumber} inserted successfully (${batch.length} records)`);
  return data;
}

/**
 * Sleep for a specified duration (to avoid rate limits)
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================================
// MAIN FUNCTION
// ============================================================================

async function main() {
  console.log('\n🚀 Starting Smart Defaults Data Loader\n');
  console.log('=' .repeat(80));
  
  try {
    // Step 1: Read JSON file
    console.log('\n📖 Step 1: Reading JSON file...');
    const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
    const jsonData = JSON.parse(fileContent);
    
    if (!jsonData.combinations || !Array.isArray(jsonData.combinations)) {
      throw new Error('Invalid JSON structure: missing "combinations" array');
    }
    
    const totalRecords = jsonData.combinations.length;
    console.log(`✅ Found ${totalRecords} combinations in JSON file`);
    
    // Step 2: Check if table is empty
    console.log('\n🔍 Step 2: Checking existing data...');
    const { count, error: countError } = await supabase
      .from('smart_defaults')
      .select('*', { count: 'exact', head: true });
    
    if (countError) {
      throw new Error(`Failed to count existing records: ${countError.message}`);
    }
    
    if (count > 0) {
      console.log(`⚠️  Warning: Table already contains ${count} records`);
      console.log('   Do you want to:');
      console.log('   1. Skip loading (keep existing data) - use --skip');
      console.log('   2. Clear and reload (delete all and insert new) - use --clear');
      console.log('   3. Append (add new records without deleting) - use --append');
      
      const flag = process.argv[3];
      if (flag === '--clear') {
        console.log('\n🗑️  Clearing existing data...');
        const { error: deleteError } = await supabase
          .from('smart_defaults')
          .delete()
          .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all
        
        if (deleteError) {
          throw new Error(`Failed to clear data: ${deleteError.message}`);
        }
        console.log('✅ Existing data cleared');
      } else if (flag === '--skip') {
        console.log('✅ Skipping load. Exiting.');
        return;
      } else if (flag !== '--append') {
        console.log('❌ No flag provided. Exiting to prevent accidental data modification.');
        console.log('   Run again with --skip, --clear, or --append');
        return;
      }
    } else {
      console.log('✅ Table is empty, proceeding with load');
    }
    
    // Step 3: Transform data
    console.log('\n🔄 Step 3: Transforming data...');
    const transformedRecords = jsonData.combinations.map(transformRecord);
    console.log(`✅ Transformed ${transformedRecords.length} records`);
    
    // Step 4: Validate data
    console.log('\n✔️  Step 4: Validating data...');
    const invalidRecords = transformedRecords.filter(r => 
      !r.style || !r.room_type || !r.specifications || !r.checklist || !r.finishes
    );
    
    if (invalidRecords.length > 0) {
      console.error(`❌ Found ${invalidRecords.length} invalid records`);
      console.error('   First invalid record:', invalidRecords[0]);
      throw new Error('Data validation failed');
    }
    console.log('✅ All records are valid');
    
    // Step 5: Insert data in batches
    console.log('\n📥 Step 5: Inserting data into database...');
    const totalBatches = Math.ceil(transformedRecords.length / BATCH_SIZE);
    console.log(`   Total batches: ${totalBatches} (${BATCH_SIZE} records per batch)`);
    
    let insertedCount = 0;
    for (let i = 1; i <= totalBatches; i++) {
      const inserted = await insertBatch(transformedRecords, i, totalBatches);
      insertedCount += inserted.length;
      
      // Sleep between batches to avoid rate limits
      if (i < totalBatches) {
        await sleep(500); // 500ms delay
      }
    }
    
    console.log(`\n✅ Successfully inserted ${insertedCount} records`);
    
    // Step 6: Verify insertion
    console.log('\n🔍 Step 6: Verifying insertion...');
    const { count: finalCount, error: finalCountError } = await supabase
      .from('smart_defaults')
      .select('*', { count: 'exact', head: true });
    
    if (finalCountError) {
      throw new Error(`Failed to verify: ${finalCountError.message}`);
    }
    
    console.log(`✅ Final record count: ${finalCount}`);
    
    // Step 7: Test helper functions
    console.log('\n🧪 Step 7: Testing helper functions...');
    
    // Test get_smart_default
    const { data: testDefault, error: testError } = await supabase
      .rpc('get_smart_default', {
        p_style: 'Modern Indian',
        p_room_type: 'Living Room'
      });
    
    if (testError) {
      console.error('❌ Error testing get_smart_default:', testError.message);
    } else if (testDefault && testDefault.length > 0) {
      console.log('✅ get_smart_default() works correctly');
      console.log(`   Found: ${testDefault[0].style} - ${testDefault[0].room_type}`);
    } else {
      console.log('⚠️  get_smart_default() returned no results');
    }
    
    // Test get_available_styles
    const { data: styles, error: stylesError } = await supabase
      .rpc('get_available_styles');
    
    if (stylesError) {
      console.error('❌ Error testing get_available_styles:', stylesError.message);
    } else {
      console.log(`✅ get_available_styles() works correctly (${styles.length} styles)`);
    }
    
    // Test get_available_room_types
    const { data: roomTypes, error: roomTypesError } = await supabase
      .rpc('get_available_room_types');
    
    if (roomTypesError) {
      console.error('❌ Error testing get_available_room_types:', roomTypesError.message);
    } else {
      console.log(`✅ get_available_room_types() works correctly (${roomTypes.length} room types)`);
    }
    
    // Step 8: Summary
    console.log('\n' + '='.repeat(80));
    console.log('🎉 DATA LOADING COMPLETE!');
    console.log('='.repeat(80));
    console.log(`\n📊 Summary:`);
    console.log(`   - Total records in JSON: ${totalRecords}`);
    console.log(`   - Records inserted: ${insertedCount}`);
    console.log(`   - Final count in database: ${finalCount}`);
    console.log(`   - Styles available: ${styles?.length || 'N/A'}`);
    console.log(`   - Room types available: ${roomTypes?.length || 'N/A'}`);
    console.log('\n✅ Smart defaults are now ready to use!');
    console.log('\n📝 Next steps:');
    console.log('   1. Update frontend to fetch from database instead of using mock data');
    console.log('   2. Test the UI to ensure smart defaults load correctly');
    console.log('   3. Proceed to connect library references to AI generation');
    console.log('\n');
    
  } catch (error) {
    console.error('\n❌ FATAL ERROR:', error.message);
    console.error('\nStack trace:', error.stack);
    process.exit(1);
  }
}

// ============================================================================
// RUN
// ============================================================================

main();
